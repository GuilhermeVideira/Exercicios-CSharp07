﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analise_e_projeto_de_sistemass
{
    abstract class Pessoa
    {
        public String nome { get; set; }
        public String cpf { get; set; }
    }
}
